<?php

// на удаленном сервере
//    $db = mysql_connect ("10.78.101.141","shkolaco_support","16213150z"); // локально
//    mysql_select_db ("shkolaco_baza",$db);
//    mysql_query("SET NAMES 'utf8'");

// на локалке
$db = mysql_connect ("localhost","root","root"); // локально
mysql_select_db ("systemagaz",$db);
mysql_query("SET NAMES 'utf8'");
?>