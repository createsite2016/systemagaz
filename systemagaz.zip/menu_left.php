<?php
$login = $_SESSION['login'];
$sql222 = mysql_query("SELECT * FROM `users_8897532` WHERE `login`='$login'",$db); //извлекаем из базы все данные о пользователе с введенным логином
$data222 = mysql_fetch_array($sql222);
$id_user = $data222['id'];


$sql_us = mysql_query("SELECT * FROM `users_8897532` WHERE `id`<>'$id_user' ",$db); //извлекаем из базы все данные о пользователе с введенным логином
$us_ids = mysql_fetch_array($sql_us);
 ?>
      <li><a href="index.php"><i class="icon-credit-card icon-xlarge"></i><span>Заказы</span></a></li>
      <li class="dropdown-submenu"><a href="products.php"><i class="icon-sitemap  icon-xlarge"></i>Товары</a>

<?php
// ДОСТУП ДЛЯ МЕНЕДЖЕРОВ
if ($user_role=='1') { ?>
      </li>
         <?php } ?>

<?php
// ДОСТУП ТОЛЬКО ДЛЯ АДМИНИСТРАТОРОВ
if ($user_role=='3') { ?>
    <ul class="dropdown-menu">
          <li><a href="way.php"><i class="icon-truck"></i>В пути</a></li>
      </ul>
      </li>   
      <li><a href="prihod.php"><i class="icon-smile icon-xlarge"></i><span>Приходы</span></a></li>
      <li><a href="rashod.php"><i class="icon-frown icon-xlarge"></i><span>Расходы</span></a></li>


      <li class="dropdown-submenu">
        <a href="#"><i class="icon-folder-open icon-xlarge"></i><span>Справочники</span></a>
        <ul class="dropdown-menu">
          <li><a href="magazins.php"><i class="icon-shopping-cart"></i>Магазины</a></li>
          <li><a href="status.php"><i class="icon-credit-card"></i>Статусы (Заказы)</a></li>
          <li><a href="status_pr.php"><i class="icon-plus"></i>Статусы (+Приходы)</a></li>
          <li><a href="status_rs.php"><i class="icon-minus"></i>Статусы (-Расходы)</a></li>
          <li><a href="dostavka.php"><i class="icon-plane"></i>Службы доставки</a></li>
          <li><a href="potavshiki.php"><i class="icon-globe"></i>Поставщики</a></li>
          <li><a href="money.php"><i class="icon-money"></i>Валюта</a></li>
        </ul>
      </li>

      <li><a href="score.php"><i class="icon-dollar icon-xlarge"></i><span>Итого</span></a></li>
<?php } ?>

