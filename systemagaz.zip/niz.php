  <footer id="footer">
    <div class="text-center padder clearfix">
      <p>
<?php
$datatime = date("Y");
echo "<small>&copy; Система управления заказами ". $datatime ."</small><br><br>";
?>
<img src="images/logo.png" width="200" height="30">
</p>
    </div>
  </footer>
  <a href="#" class="hide slide-nav-block" data-toggle="class:slide-nav slide-nav-left" data-target="body"></a>
  <!-- / footer -->
<script src="js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="js/bootstrap.js"></script>
  <!-- app -->
  <script src="js/app.js"></script>
  <script src="js/app.plugin.js"></script>
  <script src="js/app.data.js"></script>
  <!-- fuelux -->
  <script src="js/fuelux/fuelux.js"></script>
  <!-- datepicker -->
  <script src="js/datepicker/bootstrap-datepicker.js"></script>
  <!-- slider -->
  <script src="js/slider/bootstrap-slider.js"></script>
  <!-- file input -->  
  <script src="js/file-input/bootstrap.file-input.js"></script>
  <!-- combodate -->
  <script src="js/combodate/moment.min.js"></script>
  <script src="js/combodate/combodate.js"></script>
  <!-- parsley -->
  <script src="js/parsley/parsley.min.js"></script>
  <!-- select2 -->
  <script src="js/select2/select2.min.js"></script>
 
</body>
</html>